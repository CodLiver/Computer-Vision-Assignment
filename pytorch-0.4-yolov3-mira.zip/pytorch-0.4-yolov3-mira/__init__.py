# from .detect import DetectorClass
