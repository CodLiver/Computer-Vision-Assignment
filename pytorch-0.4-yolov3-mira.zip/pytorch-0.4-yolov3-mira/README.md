pytorch-0.4-yolov3 submodule form

when you have your main file and you want to use yolov3 as a subfolder module, you can use this. Currently files are organized, as if they are under ```predictor``` file.

So your file structure should be like:

```

main/
    main.py
    predictor/
            this repo
```

And in your main file, if you want to use them:

```
from predictor.detect import detectorClass
dc=detectorClass("predictor/cfg/yolo_v3.cfg","predictor/yolov3.weights")
```

then you can call all methods by just ```dc.```

It does not allow you to train, it's just there for classification.
