import sys
import time
from PIL import Image, ImageDraw
#from models.tiny_yolo import TinyYoloNet
from utils import *
from image import letterbox_image, correct_yolo_boxes
from darknet import Darknet





class detectorClass():
    """docstring for detectorClass."""
    def __init__(self, cfgfile, weightfile):
        super(detectorClass, self).__init__()
        self.weightfile = weightfile
        self.cfgfile = cfgfile
        self.m = Darknet(self.cfgfile)
        self.m.print_network()
        self.m.load_weights(self.weightfile)
        print('Loading weights from %s... Done!' % (self.weightfile))

        if self.m.num_classes == 20:
            namesfile = 'data/voc.names'
        elif self.m.num_classes == 80:
            self.namesfile = 'data/coco.names'
        else:
            self.namesfile = 'data/names'
        self.use_cuda = torch.cuda.is_available()
        if self.use_cuda:
            self.m.cuda()

    def detect(self, imgfile, save):

        img = Image.open(imgfile).convert('RGB')
        ##analyze here, is this eval res?
        sized = letterbox_image(img, self.m.width, self.m.height)

        start = time.time()
        #check here
        boxes = do_detect(self.m, sized, 0.5, 0.4, self.use_cuda)
        correct_yolo_boxes(boxes, img.width, img.height, self.m.width, self.m.height)

        finish = time.time()
        print('%s: Predicted in %f seconds.' % (imgfile, (finish-start)))

        class_names = load_class_names(self.namesfile)
        plot_boxes(img, boxes, save, class_names)

        # task is to find the returners of plot_boxes()
        # return boxes,class_names,etc

    def detect_cv2(self, imgfile, save):
        import cv2

        img = cv2.imread(imgfile)
        sized = cv2.resize(img, (self.m.width, self.m.height))
        sized = cv2.cvtColor(sized, cv2.COLOR_BGR2RGB)

        for i in range(2):
            start = time.time()
            boxes = do_detect(self.m, sized, 0.5, 0.4, self.use_cuda)
            finish = time.time()
            if i == 1:
                print('%s: Predicted in %f seconds.' % (imgfile, (finish-start)))

        class_names = load_class_names(self.namesfile)
        plot_boxes_cv2(img, boxes, savename=save, class_names=class_names)

    def detect_skimage(self, imgfile, save):
        from skimage import io
        from skimage.transform import resize

        img = io.imread(imgfile)
        sized = resize(img, (self.m.width, self.m.height)) * 255

        for i in range(2):
            start = time.time()
            boxes = do_detect(self.m, sized, 0.5, 0.4, self.use_cuda)
            finish = time.time()
            if i == 1:
                print('%s: Predicted in %f seconds.' % (imgfile, (finish-start)))

        class_names = load_class_names(self.namesfile)
        plot_boxes_cv2(img, boxes, savename=save, class_names=class_names)

if __name__ == '__main__':
    dc=detectorClass("cfg/yolo_v3.cfg", "yolov3.weights")
    print("started")
    dc.detect("data/giraffe.jpg",'data/test.jpg')
    print("end")
